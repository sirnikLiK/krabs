k = int(input())
ko = k
for i in range(k//300):
    if ko % 300 == 0:
        print('AHG', end='')
        ko -= 300
    elif ko % 300 == 100:
        print('ABIG', end='')
        ko -= 400
    else:
        print('ABCJG', end='')
        ko -= 500
