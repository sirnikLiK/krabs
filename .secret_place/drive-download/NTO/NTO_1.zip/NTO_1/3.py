# put your python code here


n = int(input())
s = [int(i) for i in input().split()]
m = int(input())
for i in range(m):
    b, e = map(int, input().split())
    sm1 = sum(s[b-1:e:2])
    sm2 = -1*(sum(s[b:e:2]))
    print(sm1+sm2, end=' ')


