a = int(input())
b = int(input())
if b > a:
    a, b = b, a
if a//3 != b:
    x2 = b**2
    x1 = (a-b)**2
else:
    x1 = (a // 3)**2
    x2 = x1
print(x1)
print(min(x1, x2))
print(x2)
